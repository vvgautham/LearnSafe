# SmartTracker
This is a simple website for one of my IOT projects.
The project was developing a Gps Tracker with a mobile app.

This site is an advrtisment for that project. People buy the App and purchase a plan through this site.
The site is only developed using HTML, CCS and BOOTSTRAP.

The site is live at https://senuld.github.io/SmartTracker/
